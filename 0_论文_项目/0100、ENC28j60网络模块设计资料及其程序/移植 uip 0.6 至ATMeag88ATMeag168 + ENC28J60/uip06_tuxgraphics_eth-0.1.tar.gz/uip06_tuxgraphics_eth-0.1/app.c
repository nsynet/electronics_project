/*****************************************************************************
*  "A Very Simple Application" from the uIP 0.6 documentation
*****************************************************************************/

#include "app.h"

void example1_init(void)
{
	uip_listen(23);
}


void example1_app(void)
{
	if(uip_connected()){
		uip_send("Welcome! UIP + Tuxgraphics eth-board, q to quit\n", 48);
	}
	if(uip_newdata() || uip_rexmit()){
		// normally we will get q\r\n = 3 char but some
		// telent appl may send q\n
		if (uip_datalen()>2 && uip_datalen()<4 && uip_appdata[0]=='q'){
			uip_close();
		}else{
			uip_send("ok\n", 3);
		}
	}
}
