#ifndef __example1_H__
#define __example1_H__

#include <reg52.h>

extern void example1_init(void);
extern void example1_app(void);

#endif 
