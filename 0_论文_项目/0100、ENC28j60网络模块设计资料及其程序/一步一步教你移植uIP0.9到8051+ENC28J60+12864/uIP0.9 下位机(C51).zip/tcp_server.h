#ifndef __tcp_server_H__
#define __tcp_server_H__

extern void tcp_server_init(void);
extern void tcp_server_appcall(void);
/*
#ifndef UIP_APPCALL
#define UIP_APPCALL     example3_app
#endif
*/
#endif 