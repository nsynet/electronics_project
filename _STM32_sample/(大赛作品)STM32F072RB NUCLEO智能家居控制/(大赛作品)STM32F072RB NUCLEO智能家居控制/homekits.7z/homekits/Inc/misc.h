#ifndef __MISC_H
#define __MISC_H

#include "stm32f0xx_hal.h"

void delay(uint32_t t);



#endif

