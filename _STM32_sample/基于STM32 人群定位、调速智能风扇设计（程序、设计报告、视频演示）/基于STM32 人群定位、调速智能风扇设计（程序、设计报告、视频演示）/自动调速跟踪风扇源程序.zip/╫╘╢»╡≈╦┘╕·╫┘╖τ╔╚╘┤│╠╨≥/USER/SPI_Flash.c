#include "stm32f10x.h"
#include "SPI_Flash.h"
#include "stm32f10x_spi.h"

void SPI_Flash_Init(void);
u16 SPI_Flash_ReadByte(unsigned char a);
u16 SPI_Flash_SendByte(u8 byte);
void FlashPageEarse(u16 page);
void FlashPageRead(u16 page,u8 *Data);
void FlashPageWrite(u16 page,u8 *Data);
void FlashWaitBusy(void);
void AT45_RomTo_buf(unsigned char buffer,unsigned int page);
u8 AT45_buf_ToRam(unsigned char buffer,unsigned int start_address,unsigned int length);
u8 AT45_RamTo_buf(unsigned char buffer,unsigned int start_address,unsigned int length);	  
void AT45_buf_ToRom(unsigned char buffer,unsigned int page);
void AT45_page_earse(unsigned int page);


unsigned char AT45_buffer[528];

void FlashReadID(u8 *Data)
{

}

/*******************************************************************************
* Function Name  : SPI_FLASH_Init
* Description    : Initializes the peripherals used by the SPI FLASH driver.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void SPI_Flash_Init(void)
{
  SPI_InitTypeDef  SPI_InitStructure;
  GPIO_InitTypeDef GPIO_InitStructure;
   
  /* Enable SPI2 GPIOB clocks */
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_SPI1 ,ENABLE);
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
  /* Configure SPI2 pins: SCK, MISO and MOSI */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
  GPIO_Init(GPIOA, &GPIO_InitStructure);

  /* Configure PB.12 as Output push-pull, used as Flash Chip select */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_Init(GPIOA, &GPIO_InitStructure);

  /* Deselect the FLASH: Chip Select high */
  NotSelect_Flash();

  /* SPI2 configuration */ 
  SPI_InitStructure.SPI_Direction = SPI_Direction_2Lines_FullDuplex;
  SPI_InitStructure.SPI_Mode = SPI_Mode_Master;
  SPI_InitStructure.SPI_DataSize = SPI_DataSize_8b;
  SPI_InitStructure.SPI_CPOL = SPI_CPOL_High;
  SPI_InitStructure.SPI_CPHA = SPI_CPHA_2Edge;
  SPI_InitStructure.SPI_NSS = SPI_NSS_Soft;
  SPI_InitStructure.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_16;
  SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_MSB;
  SPI_InitStructure.SPI_CRCPolynomial = 7;
  SPI_Init(SPI1, &SPI_InitStructure);
  
  /* Enable SPI2  */
  SPI_Cmd(SPI1, ENABLE);   
}

/*******************************************************************************
* Function Name  : SPI_FLASH_ReadByte
* Description    : Reads a byte from the SPI Flash.
*                  This function must be used only if the Start_Read_Sequence
*                  function has been previously called.
* Input          : None
* Output         : None
* Return         : Byte Read from the SPI Flash.
*******************************************************************************/
u16 SPI_Flash_ReadByte(u8 a)
{
  return (SPI_Flash_SendByte(a));
}

/*******************************************************************************
* Function Name  : SPI_FLASH_SendByte
* Description    : Sends a byte through the SPI interface and return the byte 
*                  received from the SPI bus.
* Input          : byte : byte to send.
* Output         : None
* Return         : The value of the received byte.
*******************************************************************************/
u16 SPI_Flash_SendByte(u8 byte)
{
  /* Loop while DR register in not emplty */
  while(SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_TXE) == RESET);
  //NotSelect_Flash();  while(1);
  /* Send byte through the SPI2 peripheral */
  SPI_I2S_SendData(SPI1, byte);

  /* Wait to receive a byte */
  while(SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_RXNE) == RESET);

  /* Return the byte read from the SPI bus */
  return SPI_I2S_ReceiveData(SPI1);
}

void FlashPageEarse(u16 page)
{	

}

void FlashPageRead(u16 page,u8 *Data)
{

}

void FlashPageWrite(u16 page,u8 *Data)		//дһ��ҳ��ҳ��Χ0-4095
{
	
}

void FlashWaitBusy(void)
{
	
}

//��ָ�����洢��ҳ������ת��ָ��������
void AT45_RomTo_buf(unsigned char buffer,unsigned int page)
{ 

}

//��ȡָ��������ָ����Ԫ�����ݣ�������DF_buffer[]������
unsigned char AT45_buf_ToRam(unsigned char buffer,unsigned int start_address,unsigned int length)
{
	 return 0;
}

//��DF_buffer[]������ָ�����ȵ�����д��ָ��������
unsigned char AT45_RamTo_buf(unsigned char buffer,unsigned int start_address,unsigned int length)
{
		return 0;
}


//��ָ���������е�����д�����洢����ָ��ҳ
void AT45_buf_ToRom(unsigned char buffer,unsigned int page)
{
}

//����ָ�������洢��ҳ����ַ��Χ0-4095��
void AT45_page_earse(unsigned int page)
{

}

