#ifndef _CHECKSIGNAL_H
#define _CHECKSIGNAL_H

#include "stm32f10x.h"

void CheckSignal_Config(void);

#endif

