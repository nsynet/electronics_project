#ifndef _DEAL_DATAPACKET_H
#define _DEAL_DATAPACKET_H

#include "stm32f10x.h"

void UnpackData(void);

#endif
