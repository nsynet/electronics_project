#ifndef _BREATHELED_H
#define _BREATHELED_H

#include "stm32f10x.h"

void PWM_Config(void);

#endif
