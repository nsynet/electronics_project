#ifndef _NVIC_H
#define _NVIC_H

#include "stm32f10x.h"

void NVIC_PriorityConfig(void);

#endif
