#ifndef _DMP_EXTI_H
#define _DMP_EXTI_H

#include "stm32f10x.h"

void DMP_EXTIConfig(void);

#endif
