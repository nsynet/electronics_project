#ifndef _HAL_INFRARED_H
#define _HAL_INFRARED_H
#include "stdbool.h"


void irInit(void);
bool irHandle(void);

#endif /*_HAL_INFRARED_H*/


