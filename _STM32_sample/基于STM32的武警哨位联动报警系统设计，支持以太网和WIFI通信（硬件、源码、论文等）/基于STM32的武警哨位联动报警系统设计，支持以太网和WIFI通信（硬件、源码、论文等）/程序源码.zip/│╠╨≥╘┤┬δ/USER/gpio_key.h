#ifndef __GPIO_KEY_H
#define	__GPIO_KEY_H

void GPIO_INIT(void);

#include "stm32f10x.h"


#endif
